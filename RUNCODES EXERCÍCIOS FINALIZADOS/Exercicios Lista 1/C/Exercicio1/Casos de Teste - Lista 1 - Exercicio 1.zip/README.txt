Arquivo zip gerado em: 10/10/2018 15:05:02 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Lista 1 - Exercício 1 