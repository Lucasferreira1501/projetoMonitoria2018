Arquivo zip gerado em: 10/10/2018 15:06:26 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Lista 1 - Exercício 2